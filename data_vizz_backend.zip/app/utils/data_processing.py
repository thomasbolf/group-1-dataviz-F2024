
import pandas as pd

def process(data):
    # Convert uploaded file to DataFrame
    df = pd.read_csv(data)
    # Further processing steps as needed
    return df
                